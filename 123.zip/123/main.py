n = int(input())
cup = list(map(int, input().split(' ')))

cup.sort()
a = [4, 2, 1]
b = 0
c = 0
d = 0
e = 0

for i in range(len(cup) - 1):
    if cup[i] >= 7:
        b += 3
        cup[i] = cup[i] % 7
    if cup[i] % 2 == 1:
        d += 1
    c += cup[i]

if c % 7 != 0:
    if c % 7 == 6:
        e = 2
    else:
        e = 1

print(a, b, c, d, e, cup)

if (d // 7) * 3 + e < d * 3 - 2:
    b += d * 3 - 2

else:
    b += (d // 7) * 3 + e

print(b)