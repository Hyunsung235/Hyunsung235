def a(number):
    if number >= 90:
        return "A"
    elif number >= 80:
        return "B"
    elif number >= 70:
        return "C"
    elif number >= 60:
        return "D"
    return "F"

def b(list):
    s = []
    for i in range(len(list)):
        if list[i] % 2 == 0:
            s.append(list[i])
    return s

def c(number):
    s = 0
    if number // 10 % 3 == 0:
        s += 1
    if number % 10 % 3 == 0:
        s += 1
    print('*' * s)



#print(a(int(input())))
#print(b(list(map(int, input().split(' ')))))
#c(int(input()))





def a(number):
    cache = {}
    def result(n)
        if n not in cache.keys():
            cache[n] = func(n)
        return chache[n]

    if number % 5 == 2:
        return number
    a(number + 1)

print(a(1))