import streamlit
import urllib.request
import json
d = ''


streamlit.header('검색')
a = streamlit.text_input('검색할 글자')

if a != '':
    client_id = "xYYkkoC6BzvNHG52wQLk"
    client_secret = "bWXSv2bzSg"
    encText = urllib.parse.quote(a)
    url = "https://openapi.naver.com/v1/search/blog?query=" + encText # json 결과
    # url = "https://openapi.naver.com/v1/search/blog.xml?query=" + encText # xml 결과
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id",client_id)
    request.add_header("X-Naver-Client-Secret",client_secret)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()
    if rescode == 200 :
        response_body = response.read()
        d = (response_body.decode('utf-8'))
        data = json.loads(d)
    else:
        print("Error Code:" + rescode)


streamlit.header('URL 단축')
c = streamlit.text_input('URL')

if c != '':
    client_id = "xYYkkoC6BzvNHG52wQLk"  # 개발자센터에서 발급받은 Client ID 값
    client_secret = "bWXSv2bzSg"  # 개발자센터에서 발급받은 Client Secret 값
    encText = urllib.parse.quote("https://developers.naver.com/docs/utils/shortenurl")
    data = "url=" + encText
    url = "https://openapi.naver.com/v1/util/shorturl"
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id", client_id)
    request.add_header("X-Naver-Client-Secret", client_secret)
    response = urllib.request.urlopen(request, data=data.encode("utf-8"))
    rescode = response.getcode()
    if (rescode == 200):
        response_body = response.read()
        d = (response_body.decode('utf-8'))
        data = json.loads(d)
    else:
        print("Error Code:" + rescode)

if d != '':
    streamlit.text(data["items"]["title"]["link"])


col1, col2, col3 = st.beta_columns(3)
