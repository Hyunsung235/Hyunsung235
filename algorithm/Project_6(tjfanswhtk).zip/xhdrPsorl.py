from glob import glob

Q1 = [0, 0, 0, 0, 0, 0, 0, 0, 0]
Q2 = [0, 0, 0, 0, 0]
Q3 = [0, 0, 0]
Q4 = 0
Q5 = 0
Q6 = 0
Q7 = 0
Q8 = 0



def read_1(b, d, Q, lines):
    c = lines[d].split(':')
    Q[int(c[1][0])] += 1
    print(b.readlines())
    return Q

def read_2(b, d, Q, lines):
    c = lines[d].split(':')
    Q += int(c)

a = open('xhdrP', 'w')
e = len(glob('./*.text'))
for i in range(1,(len(glob('./*.text')) + 1)):
    b = open(str(i) + 'LOL.text', 'r')
    lines = b.readlines()
    print(lines)
    #Q1 = read_1(b, 0, Q1, lines)
    #Q2 = read_1(b, 1, Q2, lines)
    #Q3 = read_1(b, 2, Q3, lines)
    Q4 = read_2(b, 3, Q4, lines)
    Q5 = read_2(b, 4, Q5, lines)
    Q6 = read_2(b, 5, Q6, lines)
    Q7 = read_2(b, 6, Q7, lines)
    Q8 = read_2(b, 7, Q8, lines)

a.write("{}\n{}\n{}\n{}\n{}\n{}\n{}\n{}".format(Q1,Q2,Q3,Q4/e,Q5/e,Q6/e,Q7/e,Q8/e))