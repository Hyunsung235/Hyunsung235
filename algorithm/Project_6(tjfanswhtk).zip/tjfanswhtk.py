import streamlit as st
from glob import glob

st.subheader("리그 오브 레전드 설문조사")
Q1 = st.selectbox("롤 등급을 선택하세요", ("1_아이언", "2_브론즈", "3_실버", "4_골드", "5_플레티넘", "6_다이아", "7_마스터", "8_그랜드마스터", "9_챌린저"))
Q2 = st.radio("포지션을 선택하세요", ("1_탑", "2_미드", "3_정글", "4_원딜", "5_서포트"))
Q3 = st.radio("어떤 점멸 키 설정을 선호하십니까", ("1_F-점멸", "2_D-점멸", "3_점멸을 사용하지 않음"))
Q4 = st.text_input("W/L은 몇이신가요")
Q5 = st.text_input("K/D은 몇이신가요")
Q6 = st.select_slider("게임 밸런스에 대해 점수를 매긴다면 몇점인가요", (0, 1, 2, 3, 4, 5))
Q7 = st.text_input("메인 캐릭터는 무엇입니까")
Q8 = st.text_input("총 몇 시간 플레이 하셨습니까")
Q9 = st.text_input("나이가 어떻게 되십니까")
Q10 = st.checkbox("개인정보 수집 동의(필수)")

if Q10:
    if st.button("저장하시겠습니까?"):
        w = open(str(len(glob('./*.text')) + 1) + 'LOL.text', 'w')
        w.write("계급:{}:\n포지션:{}:\n점멸:{}:\n윈로:{}:\n킬뎃:{}:\n밸런스:{}:\n플탐:{}:\n나이:{}:".format(Q1,Q2,Q3,Q4,Q5,Q6,Q8,Q9))