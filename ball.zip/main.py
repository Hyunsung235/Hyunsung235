import pygame

pygame.init()

width = 1600
height = 900
f = pygame.time.Clock()
display = pygame.display.set_mode([width, height])

player = pygame.image.load('0player.png')
back_img = pygame.image.load('9background.jpg')

k = 0
f = 5
b_x = 0
p_x, p_y, p_r = 300, 100, 0

while True:

    display.blit(back_img, [b_x, 0])
    display.blit(back_img, [b_x + 1600, 0])
    b_x -= 2.5
    if b_x < -1600:
         b_x = 0


    if p_y > 800:
        p_y = 800
    else:
        p_y += 2.5

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                k -= 1
            if event.key == pygame.K_f:
                k += 1

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_a:

                k += 1
            if event.key == pygame.K_f:
                k -= 1

       # p_x += 10 *
    player = pygame.transform.rotate(player, p_r)
    pygame.time.delay(100)

    display.blit(player, [p_x, p_y])
    pygame.display.update()

p_r == 90 *