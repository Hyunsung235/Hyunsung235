import streamlit as st
from glob import glob

# 머릿말
# st.header("asdf")
#
# 준 머릿말
# st.subhead er("asdf")
#
# 막대기
# st.slider("asdf", (0, 5))
#
# 글자
# st.text_input("input asdf")
#
# *로 보이지 않게 하기
# st.text_input("input Password", type="password")
#
# 숫자
# st.number_input("input number", 2)
#
# 여러 글자
# st.text_area("input asdf asdf", "hello")
#
#
# col1, col2, col3 = st.beta_columns(3)
#
# with col1:
#    st.header("A cat")
#    st.image("https://static.streamlit.io/examples/cat.jpg", use_column_width=True)
#
# with col2:
#    st.header("button")
#    if st.button("button!!"):
#        st.write("YES")
#
# with col3:
#    st.header("Chart Data")
#    chart_data = pd.DataFrame(np.random.randn(50, 3), columns=["a", "b", "c"])
#    st.bar_chart(chart_data)

b = 0

st.subheader("리그 오브 레전드 설문조사")
Q1 = st.selectbox("롤 등급을 선택하세요",
                  ("아이언", "브론즈", "실버", "골드", "플레티넘", "다이아", "마스터", "그랜드마스터", "챌린저"))
Q2 = st.radio("포지션을 선택하세요", ("탑", "미드", "정글", "원딜", "서포트"))
Q3 = st.checkbox("점멸을 사용하십니까?")
if Q3:
    Q4 = st.radio("어떤 점멸 키 설정을 선호하십니까", ("F-점멸", "D-점멸"))
Q5 = st.text_input("W/L은 몇이신가요")
Q6 = st.text_input("K/D은 몇이신가요")
Q7 = st.select_slider("게임 밸런스에 대해 점수를 매긴다면 몇점인가요", (0, 1, 2, 3, 4, 5))
Q8 = st.text_input("메인 캐릭터는 무엇입니까")
Q9 = st.text_input("총 몇 시간 플레이하셨습니까")
Q10 = st.text_input("나이가 어떻게 되십니까")
Q11 = st.checkbox("개인정보 수집 동의(필수)")
if Q11:
    S = st.button("저장하시겠습니까?")

if S:
    a = open(str(b) + "LOL.text", 'w')
    b += 1
    a.write(str(Q1) + ' ' + str(Q2) + ' ' + str(Q3) + ' ' + str(Q4) + ' ' + str(Q5) + ' ' + str(Q6) + ' ' + str(Q7) + ' ' + str(Q8) + ' ' + str(Q9) + ' ' + str(Q10) + ' ' + str(Q11))


                #glob("./a/*.jpg"))