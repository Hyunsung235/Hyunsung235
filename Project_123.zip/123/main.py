import streamlit as st
import pandas as pd
import numpy as np

st.header("")

st.write("")
st.radio("", ("", "", ""))

st.slider("", (0, 5))

st.radio("")
st.selectbox()